import os
from PIL import Image
import colorsys

def get_color_extremes(image_path):
    """Get the lightest and darkest colors from an image."""
    img = Image.open(image_path).convert('RGB')
    pixels = list(img.getdata())
    
    # Convert RGB to HSV for better brightness comparison
    hsv_pixels = [colorsys.rgb_to_hsv(r/255, g/255, b/255) for r, g, b in pixels]
    
    # Find indices of min and max brightness
    min_idx = min(range(len(hsv_pixels)), key=lambda i: hsv_pixels[i][2])
    max_idx = max(range(len(hsv_pixels)), key=lambda i: hsv_pixels[i][2])
    
    return pixels[min_idx], pixels[max_idx]

def rgb_to_hex(rgb):
    """Convert RGB tuple to hex color string."""
    return '#{:02x}{:02x}{:02x}'.format(*rgb)

def hex_to_rgb(hex_color):
    """Convert hex color string to RGB tuple."""
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

def interpolate_color(color1, color2, factor):
    """Interpolate between two RGB colors."""
    return tuple(int(color1[i] + (color2[i] - color1[i]) * factor) for i in range(3))

def process_images(base_dir):
    """Process all images in the directory except imageMu.png."""
    # Create output directory if it doesn't exist
    output_dir = os.path.join(base_dir, "Edited_Textures")
    os.makedirs(output_dir, exist_ok=True)
    
    # Load and analyze imageMu first
    mu_path = os.path.join(base_dir, "imageMu.png")
    mu_img = Image.open(mu_path).convert('RGB')
    mu_pixels = list(mu_img.getdata())
    
    # Convert MU pixels to HSV for brightness sorting
    mu_hsv = [(i, colorsys.rgb_to_hsv(r/255, g/255, b/255)) 
              for i, (r, g, b) in enumerate(mu_pixels)]
    
    # Sort pixels by brightness (V in HSV)
    mu_sorted = sorted(mu_hsv, key=lambda x: x[1][2])
    mu_original_order = [i for i, _ in mu_hsv]
    
    # Process each PNG file in the directory
    for filename in os.listdir(base_dir):
        if filename.lower().endswith('.png') and filename != "imageMu.png":
            input_path = os.path.join(base_dir, filename)
            output_path = os.path.join(output_dir, filename)
            
            # Get darkest and lightest colors from base image
            darkest, lightest = get_color_extremes(input_path)
            
            # Create color mapping
            unique_brightnesses = sorted(list(set(hsv[2] for _, hsv in mu_hsv)))
            brightness_to_color = {}
            
            for brightness in unique_brightnesses:
                # Calculate position in gradient
                factor = (brightness - mu_sorted[0][1][2]) / (mu_sorted[-1][1][2] - mu_sorted[0][1][2])
                new_color = interpolate_color(darkest, lightest, factor)
                brightness_to_color[brightness] = new_color
            
            # Create new image with mapped colors
            new_img = Image.new('RGB', mu_img.size)
            new_pixels = []
            
            for i in mu_original_order:
                brightness = next(hsv[2] for idx, hsv in mu_hsv if idx == i)
                new_pixels.append(brightness_to_color[brightness])
            
            new_img.putdata(new_pixels)
            new_img.save(output_path)
            
            print(f"Processed {filename}")

if __name__ == "__main__":
    # Replace with your directory path
    base_directory = "."  # Current directory
    process_images(base_directory)

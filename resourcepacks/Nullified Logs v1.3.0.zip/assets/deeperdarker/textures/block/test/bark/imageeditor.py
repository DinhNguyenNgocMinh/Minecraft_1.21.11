import os
from PIL import Image
import colorsys

def get_color_extremes(image_path):
    """Get the lightest and darkest colors from an image, ignoring transparent pixels."""
    img = Image.open(image_path).convert('RGBA')
    pixels = list(img.getdata())
    
    # Filter out completely transparent pixels
    visible_pixels = [(r, g, b) for r, g, b, a in pixels if a > 0]
    
    if not visible_pixels:
        return (0, 0, 0), (255, 255, 255)  # Default if all pixels are transparent
    
    # Convert RGB to HSV for better brightness comparison
    hsv_pixels = [colorsys.rgb_to_hsv(r/255, g/255, b/255) for r, g, b in visible_pixels]
    
    # Find indices of min and max brightness
    min_idx = min(range(len(hsv_pixels)), key=lambda i: hsv_pixels[i][2])
    max_idx = max(range(len(hsv_pixels)), key=lambda i: hsv_pixels[i][2])
    
    return visible_pixels[min_idx], visible_pixels[max_idx]

def rgb_to_hex(rgb):
    """Convert RGB tuple to hex color string."""
    return '#{:02x}{:02x}{:02x}'.format(*rgb)

def hex_to_rgb(hex_color):
    """Convert hex color string to RGB tuple."""
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

def interpolate_color(color1, color2, factor):
    """Interpolate between two RGB colors."""
    return tuple(int(color1[i] + (color2[i] - color1[i]) * factor) for i in range(3))

def process_images(base_dir):
    """Process all images in the directory except imageMu.png."""
    # Create output directory if it doesn't exist
    output_dir = os.path.join(base_dir, "Edited_Textures")
    os.makedirs(output_dir, exist_ok=True)
    
    # Load and analyze imageMu first
    mu_path = os.path.join(base_dir, "imageMu.png")
    mu_img = Image.open(mu_path).convert('RGBA')
    mu_pixels = list(mu_img.getdata())
    
    # Convert MU pixels to HSV for brightness sorting, keeping track of alpha
    mu_hsv = []
    for i, (r, g, b, a) in enumerate(mu_pixels):
        if a > 0:  # Only process non-transparent pixels
            hsv = colorsys.rgb_to_hsv(r/255, g/255, b/255)
            mu_hsv.append((i, hsv, a))
    
    if not mu_hsv:
        print("Warning: imageMu.png is completely transparent!")
        return
    
    # Sort visible pixels by brightness (V in HSV)
    mu_sorted = sorted(mu_hsv, key=lambda x: x[1][2])
    
    # Process each PNG file in the directory
    for filename in os.listdir(base_dir):
        if filename.lower().endswith('.png') and filename != "imageMu.png":
            input_path = os.path.join(base_dir, filename)
            output_path = os.path.join(output_dir, filename)
            
            # Get darkest and lightest colors from base image
            darkest, lightest = get_color_extremes(input_path)
            
            # Create color mapping
            unique_brightnesses = sorted(list(set(hsv[2] for _, hsv, _ in mu_hsv)))
            brightness_to_color = {}
            
            for brightness in unique_brightnesses:
                # Calculate position in gradient
                factor = (brightness - mu_sorted[0][1][2]) / (mu_sorted[-1][1][2] - mu_sorted[0][1][2])
                new_color = interpolate_color(darkest, lightest, factor)
                brightness_to_color[brightness] = new_color
            
            # Create new image with mapped colors
            new_img = Image.new('RGBA', mu_img.size, (0, 0, 0, 0))  # Initialize with transparency
            new_pixels = []
            
            # Create mapping for all pixels
            for i, (r, g, b, a) in enumerate(mu_pixels):
                if a == 0:  # Completely transparent pixel
                    new_pixels.append((0, 0, 0, 0))
                else:
                    # Find the original HSV values for this pixel
                    hsv = colorsys.rgb_to_hsv(r/255, g/255, b/255)
                    # Get the mapped color
                    new_color = brightness_to_color[hsv[2]]
                    # Preserve original alpha
                    new_pixels.append((*new_color, a))
            
            new_img.putdata(new_pixels)
            new_img.save(output_path, "PNG")
            
            print(f"Processed {filename}")

if __name__ == "__main__":
    # Replace with your directory path
    base_directory = "."  # Current directory
    process_images(base_directory)

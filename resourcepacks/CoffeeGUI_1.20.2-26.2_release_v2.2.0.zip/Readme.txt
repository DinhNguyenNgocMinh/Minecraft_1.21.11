PATCH NOTES 

Release v2.2.0

	-Updated to 26.2
	-Changed enchanting buttons
	-Changed slot icons (armor, ingredients, etc)

Release v2.1.1

	-Added colored outline to hud elements (hearts, hunger, armor)
	-Changed Brewing Stand
	-Changed the pack icon
	-Retouched containers inner outline
	-Fixed Advancements
	-Fixed Loom slots (1.20.1 and lower)
	-Fixed 1.8 survival inventory (sorry, I keep forgetting)

Release v2.1.0

	-Release for 26.1
	-Added outlines around slots that are meant to be used together (Anvil repair, Enchanting an item with lapiz, Grindstone and others)
	-Remade hunger bar into little grains of coffee (subject to change)
	-Remade air sprites
	-Remade vehicle sprites
	-Remade ping sprites
	-Remade bundle menu
	-Remade enchantment slots
	-Remade tooltip menu
	-Touched up crosshair attack indicators
	-Touched up menu buttons
	-Touched up recipie book
	-Touched up toasts
	-Consistency between the style of buttons
	-Consistent toasts across versions
	-Fixed advancements
	-Added Assets.aseprite for easier custom content

Release v2.0.2

	-Fixed locator bar

Release v2.0.1

	-Fixed loom slot that was one pixel off
	-Fixed compatibility with 1.21.5 and older, it seems it was something with shaders, honestly I have no idea what it was or how I fixed it but it is done now
	-Apparently 1.21.9 and 1.21.10 were displaying as not compatible despite working? It's fixed now
	-Added compat from 1.20.2 to 1.21.1

Release v2.0.0

	-Reworked the visuals to be a bit further from vanilla and have it’s own more unique style
	-Changed to a more rounded look for inventories and menu buttons
	-Reworked some colors to be more pleasing to look at (mainly for the inventory slots)
	-Remade the shading style of the inventory slots, previews one could make some items appear to not be centered
	-Selection now has an intense yellow color to make it more distinct and because it looks cool
	-Remade the hotbar
	-Added different shapes for slots with different functions (like circles for hotbar and output)
	-Added shading to empty armor slots and other
	-Added a coffee pattern to most inventories (might not work properly with some mods due to tiling)
	-Added lines which separate hotbar, inventory and block interfaces
	-Added different sprites for progress bar of furnace, smoker and blast furnace
	-Changed trading arrows to be thumbs ups and downs cause why not
	-Cleaned up some unnecessary details on interfaces (like background for the map on cartography table or line details on loom and grindstone)
	-Added a little guy (Accessibility icon change)

Do not distribute or republish anywhere else without permission, the only page that offers this resourcepack is Modrinth and Planet Minecraft, and only by me. If you see any version of this resourcepack anywhere else, do not download, it was uploaded without my supervision and could be dangerous.

Modrinth: https://modrinth.com/resourcepack/dark-coffe-gui
Planet Minecraft: https://www.planetminecraft.com/texture-pack/dark-coffe-gui/
Ko-Fi (if you want 👉👈): https://ko-fi.com/restlesspip